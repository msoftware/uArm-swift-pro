#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import tkinter 
import os
import sys
from time import sleep
from tkinter import filedialog
from tkinter import *
from uf.wrapper.swift_api import SwiftAPI
from uf.utils.log import *

speed = 15000   # speed Arm
zh = 60         # hoehe Arm
xw = 200        # x start Arm

sl = 0.1        # Ton Pause

w0 = 90         # Wrist Start
w1 = 110        # Wrist Ton schlagen

pc = 78         # y Position C Ton
pw = 18         # y Positionen Tonplatten


def parken():
    swift.set_position(120, 0, zh, speed = speed ) 
    swift.set_wrist(w0, wait = True)
    swift.flush_cmd()
def destructor():
     print("[INFO] Beendet...")
     swift.flush_cmd()
     main.destroy()
def file_song():
    global song
    main.filename =  filedialog.askopenfilename(initialdir = "Songs",title = "Select file",filetypes = (("txt files","*.txt"),("all files","*.*")))
    try:
        with open(main.filename,'r') as fsong:
            song = fsong.read().strip() 
    except:
            print("No file exists")
    #print(song)
    main.title(main.filename)
    fsong.close()
def ton():
    swift.set_wrist(w1, wait = True)
    sleep(sl)
    swift.set_wrist(w0, wait = True)
    #sleep(sl)
def c():
    swift.set_position(xw, pc, zh, speed = speed,  wait = True) 
    ton()
    sleep(sl)
def d():
    swift.set_position(xw, pc-(pw*1),zh, speed = speed,  wait = True) 
    ton()
def e():
    swift.set_position(xw, pc-(pw*2), zh, speed = speed,  wait = True) 
    ton()
def f():
    swift.set_position(xw, pc-(pw*3), zh, speed = speed,  wait = True) 
    ton()
def g():
    swift.set_position(xw, pc-(pw*4), zh, speed = speed,  wait = True) 
    ton()
def a():
    swift.set_position(xw, pc-(pw*5), zh, speed = speed, wait = True) 
    ton()
def b():
    swift.set_position(xw, pc-(pw*6), zh, speed = speed, wait = True) 
    ton()
def ck():
    swift.set_position(xw, pc-(pw*7), zh, speed = speed, wait = True) 
    ton()
def p2():
    sleep(0.3)
    sleep(0.3)
def test():
    song = 'CDEFGABc'
    index = 0 
    while index < len(song): 
        note = song[index] 
        print(note) 
        if note == 'C':
            c()
            sleep(1)
        if note == 'D':
            d()
            sleep(1)
        if note == 'E':
            e()
            sleep(1)
        if note == 'F':
            f()
            sleep(1)
        if note == 'G':
            g()
            sleep(1)
        if note == 'A':
            a()
            sleep(1)
        if note == 'B':
            b()
            sleep(1)
        if note == 'c':
            ck()
            sleep(1)
        index = index + 1 
    parken() 
def song_spielen():
    try:
        index = 0 
        while index < len(song): 
            note = song[index] 
            #print(note) 
            if note == 'C':
                c()
            if note == 'D':
                d()
            if note == 'E':
                e()
            if note == 'F':
                f()
            if note == 'G':
                g()
            if note == 'A':
                a()
            if note == 'B':
                b()
            if note == 'c':
                ck()
            if note == '2':
                p2()
            if note == '4':
                p2()
                p2()
            index = index + 1 
        parken() 
    except:
        print("No file exists")

swift = SwiftAPI() # {'hwid': 'USB VID:PID=2341:0042'}
sleep(2)
parken()

main = tkinter.Tk() 
fr = tkinter.Frame(main, height=550, width=750,bg="#FFFFFF", bd=10)
fr.grid(row=0, column =10, padx = 10, pady = 10)
main.title("uArm play Xylophon")   
main.protocol('WM_DELETE_WINDOW', destructor)
panel = tkinter.Label(main)
panel.grid(row=0, column =10, padx = 1, pady = 1)

logo = PhotoImage(file='Songs/titel.png')
image = Label(main,compound = CENTER,image=logo)
image.grid(row=0, column =10, padx = 1, pady = 1)

spielen = tkinter.Button(main,width='80', text="Song spielen",command=song_spielen)
spielen.grid(row=48, column=10 , padx = 10, pady = 10)

mBar = tkinter.Menu(main)
mSys = tkinter.Menu(mBar)
mSys.add_command(label="Song laden",command=file_song)  
mSys.add_command(label="Testen / Justieren",command=test)  
mSys.add_command(label="uArm parken" ,command=parken)
mSys.add_separator()
mSys.add_command(label="Beenden", command=destructor)
mBar.add_cascade(label="Song laden", menu=mSys)
main["menu"] = mBar
print("[INFO] Programmstart...")

main.mainloop()
